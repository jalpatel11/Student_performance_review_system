# Student-Performance-Review-System

This is a performance review system GUI made using Tkinter, SQLite3(Database).
It helps in efficient review by providing data visualizations through graphs, charts etc.

### There are 4 project files:
1. Documentation file
2. Project (Database file)
3. Python file (source code)
4. Image folder (containing Image files)



https://user-images.githubusercontent.com/76638140/170659449-6b8ce38b-9cce-413f-800d-9ebce31c66aa.mp4

